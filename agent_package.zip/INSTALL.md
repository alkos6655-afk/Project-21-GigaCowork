# Установка и запуск агента «Распределение ФУЛ»

## Состав архива
- `order-distribution.zip` — навык: `SKILL.md`, `scripts/distribute.py`, `references/` (правила, группы, синонимы колонок, форма Cloud, `config.json`).
- `system_prompt.txt` — системный промпт агента.
- `INSTALL.md` — эта инструкция.

## Установка в GigaCowork
1. Создайте агента, например «Распределение ФУЛ».
2. Вставьте текст из `system_prompt.txt` в поле системного промпта.
3. Загрузите навык `order-distribution.zip` (внутри папка `order-distribution/` с `SKILL.md`) и подключите его к агенту.
4. Нужны Python 3.8+ и пакеты `openpyxl` (и `xlrd` для .xls). Сеть не нужна.

## Запуск
Выберите агента, приложите три выгрузки (ФУЛ из 1С, реестр Cloud, сотрудники из 1С) в любом порядке и с любыми именами, затем отправьте пустое сообщение. Агент вернёт файл `distribution_result.xlsx` и короткую сводку.

## Ручная проверка навыка без модели
```
unzip order-distribution.zip
python3 order-distribution/scripts/distribute.py --out ./result ful.xlsx cloud.xlsx employees.xlsx
```
В stdout выводится JSON со сводкой, результат появляется в `./result/distribution_result.xlsx`.

## Настройка
Синонимы колонок, список стран «Китай», способы доставки и исключаемые должности хранятся в `references/config.json`. Правила описаны в `references/rules.md`.
