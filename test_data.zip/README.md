# Тестовые данные и результаты прогонов

- `set1_clean/` — три выгрузки: `1c_ful.xlsx` (27 ФУЛ), `cloud_registry.xlsx` (36 строк), `employees_1c.xlsx` (11 сотрудников).
- `set2_messy/` — те же данные: другие имена файлов и листов, синонимы заголовков, лишние колонки, другой порядок колонок, шапка ФУЛ в 3-й строке, сотрудники в .xls.
- `reference.xlsx` — эталон: результат по каждому ФУЛ и ловушка, которую он проверяет, эталон строк Cloud, ожидаемые итоги, ловушки без данных.
- `generate_test_data.py` — генератор (seed = 21): `python3 generate_test_data.py --out .`
- `testing/run_tests.py` — контрольные прогоны и метрики: `python3 testing/run_tests.py --skill <папка навыка> --data . --out runs --runs 3`
- `testing/runs/` — логи и результаты 3 прогонов × 2 набора (`metrics.json`, `console.log`, stdout, distribution_result.xlsx).
- `testing/mutation_results.json` — проверка чувствительности эталона: в скрипт по одной вносились ошибки.
- `testing/run_with_gigachat.py` — необязательная обёртка «скрипт + GigaChat API». Ключ передаётся через GIGACHAT_AUTH_KEY. При подготовке с реальным ключом не запускалась.
