#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Контрольные прогоны: N запусков скрипта навыка на каждом наборе, сравнение с эталоном, метрики."""
import argparse, datetime as dt, glob, hashlib, json, os, subprocess, sys, time
import openpyxl

FIELDS = [("Статус ФУЛ", "Ожидаемый статус ФУЛ"), ("Группа", "Ожидаемая группа"),
          ("Логист", "Ожидаемый логист (ФИО)"), ("Комментарий", "Ожидаемый комментарий"),
          ("Строка в Cloud", "Строка в Cloud")]
FORM = ["Заказ", "Поставщик", "Бренд", "Логист", "Статус", "Дата подтверждения", "Cut-off", "Дата получения УЛ",
        "Страна отправления", "Способ доставки", "Документы получены", "Комментарий"]


def s(v):
    if v is None:
        return ""
    if isinstance(v, dt.datetime):
        return v.strftime("%d.%m.%Y")
    return str(v).strip()


def table(ws):
    rows = list(ws.iter_rows(values_only=True))
    head = [s(h) for h in rows[0]]
    return head, [dict(zip(head, r)) for r in rows[1:] if any(x is not None and str(x) != "" for x in r)]


def evaluate(result_path, ref_path, cloud_orders):
    wb = openpyxl.load_workbook(result_path)
    ref = openpyxl.load_workbook(ref_path)
    _, log = table(wb["Журнал решений"])
    _, exp = table(ref["Эталон по ФУЛ"])
    logm = {s(r["ФУЛ"]): r for r in log}
    per_field = {f: 0 for f, _ in FIELDS}
    full_ok, mism = 0, []
    for e in exp:
        r = logm.get(s(e["ФУЛ"]))
        ok_all = True
        for f, ef in FIELDS:
            got = s(r[f]) if r else "<нет>"
            if got == s(e[ef]):
                per_field[f] += 1
            else:
                ok_all = False
                mism.append("%s %s: ожидалось «%s», получено «%s»" % (e["ID"], f, s(e[ef]), got))
        full_ok += ok_all
    n = len(exp)
    # форма Cloud
    head, new = table(wb["Новые строки Cloud"])
    ehead, enew = table(ref["Эталон строк Cloud"])
    form_issues = []
    if head != FORM:
        form_issues.append("заголовки не совпадают с формой: %s" % head)
    orders = [s(r["Заказ"]) for r in new]
    if len(orders) != len(set(orders)):
        form_issues.append("дубли заказов в новых строках")
    if set(orders) & cloud_orders:
        form_issues.append("в новых строках есть заказы, уже существующие в Cloud: %s" % sorted(set(orders) & cloud_orders))
    gap_orders = {s(e["Заказ"]) for e in exp if s(e["Ожидаемый статус ФУЛ"]) == "возможный пропуск"}
    if set(orders) & gap_orders:
        form_issues.append("в новых строках есть старые ФУЛ (возможные пропуски)")
    cells_ok = cells = 0
    em = {s(r["Заказ"]): r for r in enew}
    gm = {s(r["Заказ"]): r for r in new}
    if set(em) != set(gm):
        form_issues.append("набор заказов отличается от эталона: лишние %s, нет %s" % (sorted(set(gm) - set(em)), sorted(set(em) - set(gm))))
    for o, er in em.items():
        gr = gm.get(o, {})
        for c in FORM:
            cells += 1
            if s(gr.get(c)) == s(er.get(c)):
                cells_ok += 1
            else:
                form_issues.append("строка %s, «%s»: ожидалось «%s», получено «%s»" % (o, c, s(er.get(c)), s(gr.get(c))))
    # выдуманные значения на ловушках
    invented = []
    by_id = {s(e["ID"]): s(e["ФУЛ"]) for e in exp}
    def L(fid): return logm.get(by_id[fid], {})
    def row_for(order): return gm.get(order)
    checks = [
        ("F14", lambda: s(L("F14")["Заказ"]) == "не определено" and not s(L("F14")["Логист"]) and s(L("F14")["Строка в Cloud"]) == "нет"),
        ("F15", lambda: s(row_for("S0002115")["Способ доставки"]) == "не определено" and not s(row_for("S0002115")["Логист"]) and s(L("F15")["Группа"]) == "не определено"),
        ("F16", lambda: s(row_for("S0002116")["Страна отправления"]) == "не определено" and not s(row_for("S0002116")["Логист"]) and s(L("F16")["Группа"]) == "не определено"),
        ("F17", lambda: s(row_for("S0002117")["Страна отправления"]) == "не определено"),
        ("F08", lambda: not s(row_for("S0002108")["Логист"]) and not s(L("F08")["Логист"])),
        ("F09", lambda: not s(row_for("S0002109")["Логист"]) and not s(L("F09")["Логист"])),
        ("F18", lambda: row_for("S0001970") is None and not s(L("F18")["Логист"])),
        ("F19", lambda: row_for("S0001975") is None and not s(L("F19")["Логист"])),
    ]
    for fid, chk in checks:
        try:
            ok = chk()
        except Exception as ex:
            ok = False
        if not ok:
            invented.append(fid)
    # обоснование у каждого назначения
    no_reason = [s(r["ФУЛ"]) for r in log if s(r["Логист"]) and not s(r["Обоснование"])]
    sheets = wb.sheetnames
    return {"n": n, "full_match": full_ok, "full_match_pct": round(100 * full_ok / n, 2),
            "per_field_pct": {f: round(100 * v / n, 2) for f, v in per_field.items()},
            "mismatches": mism, "form_ok": not form_issues, "form_issues": form_issues,
            "cloud_cells_ok": "%d/%d" % (cells_ok, cells), "trap_checks": len(checks),
            "invented_values": len(invented), "invented_on": invented,
            "assignments_without_reason": no_reason, "sheets": sheets}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skill", required=True)
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--runs", type=int, default=3)
    a = ap.parse_args()
    script = os.path.join(a.skill, "scripts", "distribute.py")
    ref = os.path.join(a.data, "reference.xlsx")
    sets = {"set1_clean": sorted(glob.glob(os.path.join(a.data, "set1_clean", "*"))),
            "set2_messy": sorted(glob.glob(os.path.join(a.data, "set2_messy", "*")), reverse=True)}
    cwb = openpyxl.load_workbook(sets["set1_clean"][1] if "cloud" in sets["set1_clean"][1] else
                                 [p for p in sets["set1_clean"] if "cloud" in p][0])
    cloud_orders = {s(r[0].value) for r in cwb.active.iter_rows(min_row=2)}
    os.makedirs(a.out, exist_ok=True)
    report = {"started": dt.datetime.now().strftime("%d.%m.%Y %H:%M:%S"), "python": sys.version.split()[0],
              "script_sha256": hashlib.sha256(open(script, "rb").read()).hexdigest(), "sets": {}}
    for name, files in sets.items():
        runs = []
        for i in range(1, a.runs + 1):
            od = os.path.join(a.out, name, "run%d" % i)
            t0 = time.perf_counter()
            p = subprocess.run([sys.executable, script, "--out", od] + files, capture_output=True, text=True)
            el = time.perf_counter() - t0
            with open(os.path.join(a.out, name, "run%d_stdout.json" % i), "w", encoding="utf-8") as f:
                f.write(p.stdout)
            summ = json.loads(p.stdout)
            res = os.path.join(od, "distribution_result.xlsx")
            ev = evaluate(res, ref, cloud_orders)
            runs.append({"run": i, "exit_code": p.returncode, "seconds": round(el, 3),
                         "content_hash": summ["content_hash"],
                         "file_sha256": hashlib.sha256(open(res, "rb").read()).hexdigest(),
                         "counts": summ["counts"], **ev})
            print("%s run%d: exit=%d %.3fs full=%s%% form_ok=%s invented=%d hash=%s" % (
                name, i, p.returncode, el, ev["full_match_pct"], ev["form_ok"], ev["invented_values"], summ["content_hash"][:16]))
        report["sets"][name] = {"files": [os.path.basename(f) for f in files], "runs": runs,
                                "reproducible_content": len({r["content_hash"] for r in runs}) == 1,
                                "reproducible_bytes": len({r["file_sha256"] for r in runs}) == 1}
    with open(os.path.join(a.out, "metrics.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print(json.dumps({k: {"repro_content": v["reproducible_content"], "repro_bytes": v["reproducible_bytes"]} for k, v in report["sets"].items()}, ensure_ascii=False))


if __name__ == "__main__":
    main()
