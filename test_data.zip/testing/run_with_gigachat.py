#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Необязательная обёртка «скрипт навыка + GigaChat API» (упрощённый вариант из задания):
1) запускает scripts/distribute.py на приложенных файлах (решения принимает скрипт);
2) отправляет системный промпт + SKILL.md + stdout скрипта в GigaChat; модель пишет ответ пользователю.
Пользовательское сообщение пустое, как в целевом сценарии.

Только стандартная библиотека (urllib). Ключ авторизации берётся из GIGACHAT_AUTH_KEY
(Authorization key из личного кабинета developers.sber.ru, Base64 client_id:secret).
Переменные: GIGACHAT_SCOPE (по умолчанию GIGACHAT_API_PERS), GIGACHAT_MODEL (по умолчанию GigaChat-2-Max),
GIGACHAT_CA_BUNDLE — путь к сертификату НУЦ Минцифры (Russian Trusted Root CA), если его нет в системе.

ВНИМАНИЕ: при подготовке тестового обёртка с реальным ключом НЕ запускалась (доступа к GigaChat не было).

Пример:
  export GIGACHAT_AUTH_KEY=...
  python3 run_with_gigachat.py --skill ../order-distribution --prompt ../system_prompt.txt --out ./res f1.xlsx f2.xlsx f3.xlsx
"""
import argparse, json, os, ssl, subprocess, sys, time, urllib.request, uuid

OAUTH_URL = "https://ngw.devices.sberbank.ru:9443/api/v2/oauth"
CHAT_URL = "https://gigachat.devices.sberbank.ru/api/v1/chat/completions"


def ssl_ctx():
    ca = os.environ.get("GIGACHAT_CA_BUNDLE")
    return ssl.create_default_context(cafile=ca) if ca else ssl.create_default_context()


def get_token(key, scope):
    req = urllib.request.Request(OAUTH_URL, data=("scope=" + scope).encode(), method="POST", headers={
        "Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json",
        "RqUID": str(uuid.uuid4()), "Authorization": "Basic " + key})
    with urllib.request.urlopen(req, context=ssl_ctx(), timeout=30) as r:
        return json.load(r)["access_token"]


def chat(token, model, messages):
    body = json.dumps({"model": model, "messages": messages, "temperature": 0.01}).encode("utf-8")
    req = urllib.request.Request(CHAT_URL, data=body, method="POST", headers={
        "Content-Type": "application/json", "Accept": "application/json", "Authorization": "Bearer " + token})
    with urllib.request.urlopen(req, context=ssl_ctx(), timeout=120) as r:
        return json.load(r)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skill", required=True, help="папка навыка order-distribution")
    ap.add_argument("--prompt", required=True, help="system_prompt.txt")
    ap.add_argument("--out", required=True)
    ap.add_argument("inputs", nargs="+")
    a = ap.parse_args()
    key = os.environ.get("GIGACHAT_AUTH_KEY")
    if not key:
        sys.exit("Задайте переменную окружения GIGACHAT_AUTH_KEY")
    t0 = time.perf_counter()
    p = subprocess.run([sys.executable, os.path.join(a.skill, "scripts", "distribute.py"), "--out", a.out] + a.inputs,
                       capture_output=True, text=True)
    t_script = time.perf_counter() - t0
    system = open(a.prompt, encoding="utf-8").read() + "\n\n--- SKILL.md ---\n" + \
        open(os.path.join(a.skill, "SKILL.md"), encoding="utf-8").read()
    messages = [
        {"role": "system", "content": system},
        {"role": "user", "content": ""},  # запуск без текста запроса
        {"role": "assistant", "content": "Запускаю навык order-distribution на приложенных файлах."},
        {"role": "user", "content": "Вывод скрипта навыка (stdout):\n" + p.stdout +
         "\nСформируй ответ пользователю по шаблону из SKILL.md."},
    ]
    token = get_token(key, os.environ.get("GIGACHAT_SCOPE", "GIGACHAT_API_PERS"))
    resp = chat(token, os.environ.get("GIGACHAT_MODEL", "GigaChat-2-Max"), messages)
    t_total = time.perf_counter() - t0
    answer = resp["choices"][0]["message"]["content"]
    log = {"script_exit": p.returncode, "script_seconds": round(t_script, 3), "total_seconds": round(t_total, 3),
           "model": resp.get("model"), "usage": resp.get("usage"), "answer": answer}
    os.makedirs(a.out, exist_ok=True)
    with open(os.path.join(a.out, "gigachat_run_log.json"), "w", encoding="utf-8") as f:
        json.dump(log, f, ensure_ascii=False, indent=2)
    print(answer)


if __name__ == "__main__":
    main()
